var _AllowlistStoreDefs = {
    bloomfilterStoreName: "bf",
    bloomfilterStoreKeyName: "name",
    bloomfilterStoreEntryName: "default",
    bloomfilterStoreBitmapName: "bitmap",
    bloomfilterStoreHashName: "hash",
    urlPatternsStoreName: "urlPatterns",
    urlPatternsStoreKeyName: "domain",
    urlPatternsStoreValueName: "pattern"
};
