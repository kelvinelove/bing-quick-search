# bing-quick-search
 A Microsoft Edge extension that enables you to right click on a selection and search, all without leaving your current window
